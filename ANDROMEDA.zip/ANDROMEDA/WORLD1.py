
import pygame
from pygame.locals import *
import sys

from game import *
 

#inicia pygame
pygame.init()

#Variables para usar dps
vec = pygame.math.Vector2 
WIDTH, HEIGHT = 1000, 420
ACC, FRIC = 2.5, -0.3
FPS = 30
FPS_CLOCK = pygame.time.Clock()

BOSS1_ST = pygame.mixer.music.load("/MUSICA Y EFECTOS/BOSS1_ST.mp3") 
jumpsfx = pygame.mixer.Sound("Jumpsfx.mp3")
shootsfx = pygame.mixer.Sound("/Universidad/Programación/GAME/Proyecto JUEGO/Soundtrack/shootsfx.mp3")
hit_cooldown = pygame.USEREVENT + 1

WALK_ANIMATION_R = [pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/RIGHT/WALK1.png"),pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/RIGHT/WALK2.png"),
        pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/RIGHT/WALK3.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/RIGHT/WALK4.png"),
        pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/RIGHT/WALK5.png")]
WALK_ANIMATION_L = [pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/LEFT/WALK_1L.png"),pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/LEFT/WALK_2L.png"),
        pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/LEFT/WALK_3L.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/LEFT/WALK_4L.png"),
        pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/WALK/LEFT/WALK_5L.png")]
JUMP_ANIMATION = [pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/JUMP/JUMP00.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/JUMP/JUMP01.png")]
ATTACK_ANIMATION_R = [pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/Attack/RIGHT/ATTACKR1.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/Attack/RIGHT/ATTACKR2.png")]
ATTACK_ANIMATION_L = [pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/Attack/LEFT/ATTACKL1.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/Attack/LEFT/ATTACKL2.png")]
BOSS1_ATTACK = [pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/ATTACK/LEFT/ATTACK1.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/ATTACK/LEFT/ATTACK2.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/ATTACK/LEFT/ATTACK3.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/ATTACK/LEFT/ATTACK4.png")
,pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/ATTACK/LEFT/ATTACK5.png")]
PLAYER_HP = [pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/HEALTH/heart5.png"),pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/HEALTH/heart4.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/HEALTH/heart3.png"), pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/HEALTH/heart2.png")
, pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/HEALTH/heart.png")
, pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/HEALTH/heart0.png")]

displaysurface = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Proyect Andromeda")
stage_clear = False
#clases del juego
class Background(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.bgimage = pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/Background/BG1.png")
        self.bgY = 0
        self.bgX = 0
    def render(self):
        displaysurface.blit(self.bgimage, (self.bgX, self.bgY))        

background = Background()

class Ground(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/Background/Rectangulo.png")
        self.rect = self.image.get_rect(center = (500 , 420))

    def render(self):
        displaysurface.blit(self.image, (self.rect.x, self.rect.y))
        

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/Player character/GUN/GUN_IDLE1.png")
        self.rect = self.image.get_rect()
        #posicion y dirección
        self.vx = 0
        self.pos = vec((50, 340))
        self.vel = vec(0, 0)
        self.direction = "RIGHT"
        self.jumping = False
        self.running = False
        self.move_frame = 0
        #variables para disparo
        self.attacking = False
        self.attack_frame = 0
        #combate
        self.health = 5
        self.hitbox = pygame.Rect(self.pos.x - 25, self.pos.y, 30, 45)  #lugarx, lugary, dimensionx, dimensiony


    def attack(self):  #revisar
        if self.attack_frame > 1:
            self.attack_frame = 0
            self.attacking = False
        
        if self.direction == "RIGHT":
            self.image = ATTACK_ANIMATION_R[self.attack_frame]
        elif self.direction == "LEFT":
            self.image = ATTACK_ANIMATION_L[self.attack_frame]
        
        self.attack_frame += 1
    def move(self):  #fisica para moverse
        self.acc = vec(0, 0.4)
        pressed_keys = pygame.key.get_pressed()
        if pressed_keys[K_a]:
            self.running = True
            self.pos.x -= 7 
            self.hitbox.x -= 7
            self.direction = "LEFT"
        elif pressed_keys[K_d]:
            self.running = True
            self.pos.x += 7    
            self.hitbox.x += 7
            self.direction = "RIGHT"
        else:
            self.running = False
        #FISICA JASJDAJDSAD ME RIO PORQUE NO ENTIENDO
        self.acc.x += self.vel.x * FRIC
        self.vel += self.acc
        self.pos += self.vel + 0.5 * self.acc #ah?

        if self.pos.x > WIDTH:
            self.pos.x = WIDTH
        if 0 > self.pos.x:
            self.pos.x = 0        
        self.rect.midbottom = self.pos

    def update(self):
        #devuelve al frame inicial si es que esta quieto
        if self.move_frame > 4:
            self.move_frame = 0
 
        #hace un cycle por las frames si se cumplen las condiciones 
        if self.jumping == False and self.running == True and self.direction == "RIGHT":  
                self.image = WALK_ANIMATION_R[self.move_frame]
                self.move_frame += 1
        else:
            self.image = WALK_ANIMATION_L[self.move_frame]
            self.move_frame += 1
 
        #devuelve al frame inicial si esta quieto y tiene una frame incorrecta
        if abs(self.vel.x) < 0.2 and self.move_frame != 0:
            self.move_frame = 0
            if self.direction == "RIGHT":
                self.image = WALK_ANIMATION_R[self.move_frame]
            elif self.direction == "LEFT":
                self.image = WALK_ANIMATION_L[self.move_frame]
        
    def gravity_check(self):  #esta funcion crea un collision detection entre un rectangulo blanco detrás del fondo y el sprite
        hits = pygame.sprite.spritecollide(self, ground_group, False)
        if self.vel.y > 0:
            if hits:
                lowest = hits[0]
                if self.pos.y < lowest.rect.bottom:
                    self.pos.y = lowest.rect.top + 1
                    self.vel.y = 0
                    self.jumping = False


    def jump(self):   #funcion para el salto
        hits = pygame.sprite.spritecollide(self, ground_group, False)
        if hits and not self.jumping:                
            if self.direction == "RIGHT":
                self.image = JUMP_ANIMATION[0]  #como la animacion de salto es 1 frame solo se cambia una vez. 
                self.direction = 0
            elif self.direction == "LEFT":
                self.image = JUMP_ANIMATION[1]
                self.direction = 0
            self.jumping = True 
            self.vel.y = -10

    def create_bullet(self):
        return Bullet(self.pos.x, self.pos.y - 30)
    def player_hit(self):
        self.health -= 1
        hp_bar.hpframe += 1
        if self.health <= 0:
            self.kill()
            pygame.display.update()
            game.lose_screen()
            
player = Player()
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/IDLE/RIGHT/IDLE_1R.png")    
        self.rect = self.image.get_rect()
        self.pos = vec((800,285))
        self.vel = vec(0,0)
        self.hitbox = pygame.Rect(self.pos.x, self.pos.y, 34, 100)
        self.health = 20
        self.attackframe = 0
        self.attacking = False


    def move(self):
        if self.attacking == False:
            if player.pos.x > self.pos.x:  #izquierda
                self.pos.x += 3
                self.hitbox.x +=3
                self.image =  pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/IDLE/RIGHT/IDLE_1R.png")  
            elif player.pos.x < self.pos.x:   #derecha
                self.pos.x -= 3
                self.hitbox.x -=3
                self.image = pygame.image.load("/Universidad/Programación/GAME/Proyecto JUEGO/PC's & NPC's/BOSS 1/IDLE/LEFT/IDLE_1.png")

            if self.pos.x == 900: #estos if son para revisar si está al borde de la ventana
                self.pos.x = 900
            elif self.rect.x == 20:
                self.pos.x = 20
    def render(self):   
        displaysurface.blit(self.image, (self.pos.x, self.pos.y))

    def attack(self):
        if 0 < self.pos.x - player.pos.x <= 10:
            self.attacking = True   
            self.image = BOSS1_ATTACK[self.attackframe]
            pygame.time.wait(100)
            self.attackframe += 1
            if self.attackframe == 4:
                self.attackframe = 0
        else:
            self.attacking = False

enemy = Enemy()
game = Game()

class HP(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.hpframe = 0
        self.image = PLAYER_HP[self.hpframe]
        

    def render(self):
        displaysurface.blit(self.image, (0,0))   

hp_bar = HP()
ground = Ground()
ground_group = pygame.sprite.Group()
ground_group.add(ground)
Playergroup = pygame.sprite.Group()
Playergroup.add(player)

class Bullet(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.image = pygame.image.load("/Universidad/Programación/GAME/BALA.png")
        self.rect = self.image.get_rect(center = (pos_x, pos_y))
        self.hitbox = pygame.Rect(pos_x, pos_y, 10,10)
    
    def updateright(self):
        self.rect.x += 10
        self.hitbox.x += 10

        if self.rect.x >= WIDTH + 200:
            self.kill()

    def updateleft(self):
        self.rect.x -= 10
        self.hitbox.x -= 10
        
        if self.rect.x <= -10:
            self.kill()

    def collide(self):
        hit = self.hitbox.colliderect(enemy.hitbox)
        if hit:
            self.kill()
            enemy.health -= 1
            enemy.image = pygame.image.load("/Universidad/Programación/GAME/ANDROMEDA/PERSONAJES/BOSS 1/HIT/HIT1.png") 

def draw():         
    ground.render()
    background.render()    
    hp_bar.render()
    

bullet_groupright = pygame.sprite.Group()
bullet_groupleft = pygame.sprite.Group()
def colision():
    pygame.draw.rect(displaysurface,(255,0,0), enemy.hitbox)    
    pygame.draw.rect(displaysurface,(0,255,0), player.hitbox)
    hit = enemy.hitbox.colliderect(player.hitbox)
    if hit and enemy.attacking:
        player.player_hit()


def main():
    while game.running:  #importa el menu de game.py y menu.py
        game.curr_menu.display_menu()
        global stage_clear
        game.game_loop()        
        pygame.mixer.music.play()
        while True:            
            player.gravity_check()
            colision()    
            draw()
                
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
            
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_w:
                        pygame.mixer.Sound.play(jumpsfx)
                        player.jump()
                        player.running = False 
                    if event.key == pygame.K_SPACE:
                        shootsfx.play()
                        if player.direction == "RIGHT":
                            bullet_groupright.add(player.create_bullet())
                        else:
                            bullet_groupleft.add(player.create_bullet())
                        

                    
            bullet_groupright.draw(displaysurface) 
            bullet_groupleft.draw(displaysurface)           
    
            
            for i in bullet_groupright:
                i.updateright()
                i.collide()
            
            for j in bullet_groupleft:
                j.updateleft()
                j.collide()

            #player
            displaysurface.blit(player.image, player.rect)
               
            player.move() 
            player.update()           
            #enemigo
            if enemy.health > 0:
                enemy.render()
                enemy.move()  
                enemy.attack()
                
            else:
                enemy.kill()
                stage_clear = True

            pygame.display.update()
            FPS_CLOCK.tick(FPS)

main() 