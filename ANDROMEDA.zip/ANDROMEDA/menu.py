import pygame

class Menu():
    def __init__(self, game):   #variables para usar
        self.game = game
        self.mid_w, self.mid_h = self.game.DISPLAY_W / 2, self.game.DISPLAY_H / 2
        self.run_display = True
        self.cursor_rect = pygame.Rect(0, 0, 20, 20)
        self.offset = - 100

    def draw_cursor(self):   #crear el "cursor" que va a la izquierda
        self.game.draw_text('*', 40, self.cursor_rect.x - 100, self.cursor_rect.y + 10)

    def blit_screen(self):   #display 
        self.game.window.blit(self.game.display, (0, 0))
        pygame.display.update()
        self.game.reset_keys()

class MainMenu(Menu):
    def __init__(self, game):  #mas variables
        Menu.__init__(self, game)
        self.state = "Start"
        self.startx, self.starty = self.mid_w, self.mid_h + 30
        self.creditsx, self.creditsy = self.mid_w, self.mid_h + 70
        self.cursor_rect.midtop = (self.startx + self.offset, self.starty)

    def display_menu(self):  #dsta funcion muestra el menu y la opcion seleccionada
        self.run_display = True
        while self.run_display:
            self.game.check_events()
            self.check_input()
            self.game.display.fill(self.game.BLACK)
            self.game.draw_text("Proyecto: Andromeda", 80, self.game.DISPLAY_W - 500, self.game.DISPLAY_H -300)
            self.game. draw_text("StartGame", 40, self.startx, self.starty)
            self.game.draw_text("Credits", 40, self.creditsx, self.creditsy)
            self.draw_cursor()
            self.blit_screen()


    def move_cursor(self):   #esta funcion decide donde se encuentra el cursor en cada momento dado. los if y elif de afuera son virtualmente lo mismo. Cada uno vez flecha hacia arriba y el otro flecha hacia abajo
        if self.game.DOWN_KEY:
            if self.state == 'Start':
                self.cursor_rect.midtop = (self.creditsx + self.offset, self.creditsy)
                self.state = 'Credits'
            elif self.state == 'Credits':
                self.cursor_rect.midtop = (self.startx + self.offset, self.starty)
                self.state = 'Start'
        elif self.game.UP_KEY:
            if self.state == 'Start':
                self.cursor_rect.midtop = (self.creditsx + self.offset, self.creditsy)
                self.state = 'Credits'
            elif self.state == 'Credits':
                self.cursor_rect.midtop = (self.startx + self.offset, self.starty)
                self.state = 'Start'

    def check_input(self):   #esta funcion decide que hacer dependiendo de la opcion elegida
        self.move_cursor()
        if self.game.START_KEY:
            if self.state == 'Start':
                self.game.playing = True
            elif self.state == 'Credits':
                self.game.curr_menu = self.game.credits  #la funcion Credites aun no existe, por lo que elegirlo en el menu tira error
            self.run_display = False