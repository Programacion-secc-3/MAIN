import WORLD1
import WORLD2
import WORLD3

stage1 = WORLD1
stage2 = WORLD2
stage3 = WORLD3

stage1.main()

if stage1.stage_clear == True:
    stage2.main()
    if stage2.stage_clear == True:
        stage3.main()
        if stage3.stage_clear == True:
            pass